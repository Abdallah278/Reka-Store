import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const { fakeDb } = vi.hoisted(() => {
  const fakeDb = {
    insert: vi.fn(() => ({ values: vi.fn(async () => [{ insertId: 42 }]) })),
    update: vi.fn(() => ({ set: vi.fn(() => ({ where: vi.fn(async () => undefined) })) })),
    delete: vi.fn(() => ({ where: vi.fn(async () => undefined) })),
    select: vi.fn(() => ({ from: vi.fn(() => ({ limit: vi.fn(async () => []) })) })),
  };
  return { fakeDb };
});

vi.mock("./db", () => ({
  getDb: vi.fn(async () => fakeDb),
  listProducts: vi.fn(async () => []),
  getStoreSettings: vi.fn(async () => null),
}));

function adminContext(): TrpcContext {
  return {
    user: { id: 7, openId: "admin-user", name: "Owner", email: "owner@example.com", loginMethod: "test", role: "admin", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as TrpcContext["res"],
  };
}

const settings = { storeName: "Reka Store", logoUrl: null, whatsappNumber: "201000000000", primaryColor: "#310E10", accentColor: "#74070E", heroTitle: "Beauty, your way", heroSubtitle: "A considered beauty edit.", heroImageUrl: null };
const product = { name: "Velvet Tint", description: "Soft everyday color", price: 350, categoryId: null, isSoldOut: false, isPublished: true, images: [] };

describe("admin behavior", () => {
  it("creates a product and returns its id", async () => {
    const result = await appRouter.createCaller(adminContext()).admin.createProduct(product);
    expect(result).toEqual({ id: 42 });
    expect(fakeDb.insert).toHaveBeenCalled();
  });

  it("updates and deletes a product", async () => {
    const caller = appRouter.createCaller(adminContext());
    await expect(caller.admin.updateProduct({ ...product, id: 42, isSoldOut: true })).resolves.toEqual({ success: true });
    await expect(caller.admin.deleteProduct({ id: 42 })).resolves.toEqual({ success: true });
    expect(fakeDb.update).toHaveBeenCalled();
    expect(fakeDb.delete).toHaveBeenCalled();
  });

  it("saves store settings", async () => {
    await expect(appRouter.createCaller(adminContext()).admin.saveSettings(settings)).resolves.toEqual({ success: true });
    expect(fakeDb.select).toHaveBeenCalled();
    expect(fakeDb.insert).toHaveBeenCalled();
  });
});

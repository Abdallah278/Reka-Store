import { and, asc, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { categories, InsertUser, productImages, products, storeSettings, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); } catch (error) { console.warn("[Database] Failed to connect:", error); }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb(); if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = values[field]; }
  }
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  values.lastSignedIn ??= new Date(); updateSet.lastSignedIn ??= new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb(); if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listProducts(includeUnpublished = false) {
  const db = await getDb(); if (!db) return [];
  const rows = await db.select({ product: products, category: categories }).from(products)
    .leftJoin(categories, eq(products.categoryId, categories.id))
    .where(includeUnpublished ? undefined : eq(products.isPublished, 1)).orderBy(desc(products.createdAt));
  const images = await db.select().from(productImages).orderBy(asc(productImages.sortOrder));
  return rows.map(({ product, category }) => ({ ...product, categoryName: category?.name ?? "غير مصنف", images: images.filter(image => image.productId === product.id) }));
}

export async function getStoreSettings() {
  const db = await getDb(); if (!db) return { storeName: "Reka Store", logoUrl: null, whatsappNumber: "201000000000", primaryColor: "#310E10", accentColor: "#74070E", heroTitle: "Beauty, your way", heroSubtitle: "منتجات مختارة تكمّل جمالك اليومي.", heroImageUrl: null };
  const rows = await db.select().from(storeSettings).limit(1);
  return rows[0] ?? (await db.insert(storeSettings).values({}).$returningId().then(async () => (await db.select().from(storeSettings).limit(1))[0]));
}

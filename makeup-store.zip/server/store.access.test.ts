import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function context(role: "admin" | "user"): TrpcContext {
  return {
    user: { id: 7, openId: "test-user", name: "Test", email: "test@example.com", loginMethod: "test", role, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as TrpcContext["res"],
  };
}

describe("store access control", () => {
  it("rejects product administration for regular users", async () => {
    const caller = appRouter.createCaller(context("user"));
    await expect(caller.admin.products()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("rejects store settings mutations for regular users", async () => {
    const caller = appRouter.createCaller(context("user"));
    await expect(caller.admin.saveSettings({ storeName: "Luma", logoUrl: null, whatsappNumber: "201000000000", primaryColor: "#1C1917", accentColor: "#A16207", heroTitle: "جمالك", heroSubtitle: "تفاصيل", heroImageUrl: null })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});

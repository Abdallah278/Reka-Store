import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { categories, productImages, products, storeSettings } from "../drizzle/schema";
import { getDb, getStoreSettings, listProducts } from "./db";
import { storagePut } from "./storage";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { adminProcedure, publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { eq } from "drizzle-orm";

const imageInput = z.object({ url: z.string().min(1), key: z.string().min(1) });
const productInput = z.object({
  name: z.string().min(2).max(160), description: z.string().max(4000).optional(), price: z.number().int().nonnegative(),
  categoryId: z.number().int().nullable().optional(), isSoldOut: z.boolean().default(false), isPublished: z.boolean().default(true),
  images: z.array(imageInput).max(8).default([]),
});
const slugify = (value: string) => `${value.trim().toLowerCase().replace(/\s+/g, "-").replace(/[^\w\u0600-\u06FF-]/g, "").replace(/(^-|-$)/g, "")}-${Date.now()}`;
const ensureDb = async () => { const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" }); return db; };
const adminOnly = adminProcedure;

export const appRouter = router({
  system: router({}),
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => { const options = getSessionCookieOptions(ctx.req); ctx.res.clearCookie(COOKIE_NAME, { ...options, maxAge: -1 }); return { success: true } as const; }),
  }),
  store: router({
    settings: publicProcedure.query(() => getStoreSettings()),
    products: publicProcedure.input(z.object({ includeUnpublished: z.boolean().default(false) }).optional()).query(({ input, ctx }) => listProducts(Boolean(input?.includeUnpublished && ctx.user?.role === "admin"))),
    categories: publicProcedure.query(async () => { const db = await getDb(); return db ? db.select().from(categories).orderBy(categories.name) : []; }),
  }),
  admin: router({
    products: adminOnly.query(() => listProducts(true)),
    createProduct: adminOnly.input(productInput).mutation(async ({ input }) => { const db = await ensureDb(); const [created] = await db.insert(products).values({ name: input.name, slug: slugify(input.name), description: input.description ?? null, price: input.price, categoryId: input.categoryId ?? null, isSoldOut: input.isSoldOut ? 1 : 0, isPublished: input.isPublished ? 1 : 0 }); const productId = Number(created.insertId); if (input.images.length) await db.insert(productImages).values(input.images.map((image, index) => ({ productId, imageUrl: image.url, storageKey: image.key, sortOrder: index }))); return { id: productId }; }),
    updateProduct: adminOnly.input(productInput.extend({ id: z.number().int() })).mutation(async ({ input }) => { const db = await ensureDb(); await db.update(products).set({ name: input.name, description: input.description ?? null, price: input.price, categoryId: input.categoryId ?? null, isSoldOut: input.isSoldOut ? 1 : 0, isPublished: input.isPublished ? 1 : 0 }).where(eq(products.id, input.id)); await db.delete(productImages).where(eq(productImages.productId, input.id)); if (input.images.length) await db.insert(productImages).values(input.images.map((image, index) => ({ productId: input.id, imageUrl: image.url, storageKey: image.key, sortOrder: index }))); return { success: true }; }),
    deleteProduct: adminOnly.input(z.object({ id: z.number().int() })).mutation(async ({ input }) => { const db = await ensureDb(); await db.delete(productImages).where(eq(productImages.productId, input.id)); await db.delete(products).where(eq(products.id, input.id)); return { success: true }; }),
    saveSettings: adminOnly.input(z.object({ storeName: z.string().min(2).max(120), logoUrl: z.string().nullable(), whatsappNumber: z.string().min(8).max(32), primaryColor: z.string().regex(/^#[0-9A-Fa-f]{6}$/), accentColor: z.string().regex(/^#[0-9A-Fa-f]{6}$/), heroTitle: z.string().min(2).max(180), heroSubtitle: z.string().max(500), heroImageUrl: z.string().nullable() })).mutation(async ({ input }) => { const db = await ensureDb(); const existing = await db.select({ id: storeSettings.id }).from(storeSettings).limit(1); if (existing[0]) await db.update(storeSettings).set(input).where(eq(storeSettings.id, existing[0].id)); else await db.insert(storeSettings).values(input); return { success: true }; }),
    uploadImage: adminOnly.input(z.object({ dataUrl: z.string().startsWith("data:image/"), filename: z.string().max(120), mimeType: z.string().startsWith("image/") })).mutation(async ({ input, ctx }) => { const [, base64] = input.dataUrl.split(","); if (!base64) throw new TRPCError({ code: "BAD_REQUEST", message: "Invalid image" }); const result = await storagePut(`makeup/${ctx.user.id}/${input.filename}`, Buffer.from(base64, "base64"), input.mimeType); return result; }),
  }),
});
export type AppRouter = typeof appRouter;
